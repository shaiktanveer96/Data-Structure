package Arrays_prg;

public class LengthOfLastWord {
	
	public static void main(String[] args) {
		String str="i am tanveer ";
		System.out.println(lengthofword(str));
		
	}

	
	public static int lengthofword(String s) {
		
		String str=s.trim();
		System.out.println(str);
		int count=0;
		for(int i=str.length()-1 ; i>=0;i--) {
			if(str.charAt(i) !=' ') {
				count++;
			}else {
				break; 
			}
		}
		return count;
	}
}
