package Arrays_prg;

public class Ransom_Note {
	
	public static void main(String[] args) {
		
		Ransom_Note ob=new Ransom_Note();
		System.out.println(ob.Ram("a", "b"));
		
	}

	public  boolean Ram(String ram, String maz) {
		int[] count=new int[26];
		
	    for(char ch:maz.toCharArray())
	    	count[ch-'a']++;
	    for(char ch:ram.toCharArray()) {
	    	count[ch-'a']--;
	    		if(count[ch-'a']<0)
	    			return false;
	    	
	    }
	    return true;
		}
	
	}

