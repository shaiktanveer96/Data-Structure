package Arrays_prg;

public class Move_Zero {
	
	//Queus

}
