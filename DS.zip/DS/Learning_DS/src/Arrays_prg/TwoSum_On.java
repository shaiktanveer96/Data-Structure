package Arrays_prg;

import java.util.Arrays;
import java.util.HashMap;

public class TwoSum_On {

	
	public static void main(String[] args) {
		
		int [] num= {2,7,11,15};
		int target=9;
		int [] sum=twosum(num,target);
		System.out.println(Arrays.toString(twosum(num,target)));
		
	}
	
	public static int [] twosum(int[] num , int targ) {
		
		HashMap <Integer, Integer> hmap=new HashMap<>();
		int [] ans=new int[2];
		for(int i=0; i<num.length;i++) {
			int diff=targ-num[i];
			if(!hmap.containsKey(diff)) {
				hmap.put(num[i], i);
			}
			else {
				ans[0]=i;
				ans[1]=hmap.get(diff);
			}
				
		}
		return ans;
	}
}
