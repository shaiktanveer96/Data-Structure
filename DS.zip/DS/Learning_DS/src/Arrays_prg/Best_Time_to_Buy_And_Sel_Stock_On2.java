package Arrays_prg;

public class Best_Time_to_Buy_And_Sel_Stock_On2 {

	
	public static void main(String[] args) {
		
		int [] value= {7,1,5,3,6,4};
		//int [] value= {7,6,4,3,1};

		int sell_stock=maxProfit(value);
		System.out.println(sell_stock);
		
		
	}
	
	public static int maxProfit(int [] prices) {
		
		int min_val=Integer.MAX_VALUE;
		System.out.println(min_val);
		int max_proft=0;
		
		for (int i = 0; i < prices.length; i++) {
			if(prices[i] <min_val) {
				min_val=prices[i];
				System.out.println(min_val);
			}else if(prices[i] - min_val > max_proft) {
				max_proft=prices[i]-min_val;
			}
			
		}
		
		return max_proft;
	}
}
