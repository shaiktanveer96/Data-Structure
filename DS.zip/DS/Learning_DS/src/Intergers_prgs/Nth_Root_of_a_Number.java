package Intergers_prgs;

public class Nth_Root_of_a_Number {
	
	// https://www.youtube.com/watch?v=UN8ZnmFM2C0

}
