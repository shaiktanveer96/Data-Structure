package Intergers_prgs;

public class Pow {
	
	public static void main(String[] args) {
		//https://www.youtube.com/watch?v=GyL7FJn0gso
	}

}
