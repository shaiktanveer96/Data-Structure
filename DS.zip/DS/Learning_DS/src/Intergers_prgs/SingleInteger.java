package Intergers_prgs;

public class SingleInteger {
	
	public static void main(String[] args) {
	
		int[] arr= {1,5,5,3,1,2,3};
		int results=singleValue(arr);
		System.out.println(results);
		
	}
	
	public static int singleValue(int[] nums) {
		
		int result= 0;
		
		/*
		 * for(int num : nums) { result= result ^ num; }
		 */
		
		for (int i = 0; i < nums.length; i++) {
			
			result= result ^ nums[i];
			
		}
		
		return result;
	}

}
