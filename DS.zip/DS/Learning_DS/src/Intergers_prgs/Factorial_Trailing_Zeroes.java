package Intergers_prgs;

public class Factorial_Trailing_Zeroes {
	
	public static void main(String[] args) {
		
		System.out.println(trailingZero(5));
		//https://www.youtube.com/watch?v=pixOvDxipHI
	}
	
	public static int trailingZero(int n) {
		
		int count=0;
		/*
		 * int res=0; int powerof5=5;
		 * 
		 * while(n>=powerof5) { 
		 * res=res+(n/powerof5); 
		 * powerof5 = powerof5*5;
		 * 
		 * } return res;
		 */
		
		for (int i = 5; i <=n; i=i*5) {
			 count=count+n/i;
			
			
		}
		return count;
	}

}
