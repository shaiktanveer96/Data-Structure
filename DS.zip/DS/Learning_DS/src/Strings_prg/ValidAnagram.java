package Strings_prg;

public class ValidAnagram {

	public static void main(String[] args) {
		// https://www.youtube.com/watch?v=wKF6L9Zo8PQ
		String E = "anagram";
		String t = "nagarax";
		System.out.println(isAnagram(E, t));

	}
	/*
	 * public static boolean isAnagram(String E, String A) { int m=E.length(); int
	 * n=A.length();
	 * 
	 * 
	 * if(m !=n) { return false; }else { int count[] =new int[26]; for(int i=0 ;
	 * i<m;i++) { count[E.charAt(i)-'a']++; count[A.charAt(i)-'a']--;
	 * 
	 * } for(int i=0 ; i<n;i++) { count[A.charAt(i)-'a']--;
	 * 
	 * } for(int i=0 ; i<count.length;i++) { if(count[i] !=0) { return false; }
	 * 
	 * } return true; }
	 * 
	 * 
	 * }
	 */

	public static boolean isAnagram(String E, String A) {
		if (E.length() != A.length())
			return false;
		int[] count = new int[26];

		for (int i = 0; i <E.length(); i++) {
			char c1 = E.charAt(i);
			char c2 = A.charAt(i);

			count[c1 - 'a']++;
			count[c2 - 'a']--;

		}
		
		for(int i=0 ; i<count.length;i++) {
			if(count[i] !=0) {
				return false;
				
			}
		}
		return true;
		
	}

}



/*
 * 
 public static boolean  valid(String E, String A) {
		if(E.length() != A.length())
			return false;
		int [] count=new int[26];
		
		for (int i = 0; i < E.length(); i++) {
			  char C1=E.charAt(i);	
		
			  
			  count[C1 - 'a']++;
			 
			  
		}
		
		for (int i = 0; i < A.length(); i++) {
			
			  char C2=A.charAt(i);
			  
			
			  count[C2 - 'a']--;
			  
		}
		
		
		
		
		for (int i = 0; i < count.length; i++) {
			if(count[i] != 0)
				return false;
			
		}
		return true;
		
	}
 * 
 */
