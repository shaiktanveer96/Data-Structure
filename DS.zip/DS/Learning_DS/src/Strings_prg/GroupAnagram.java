package Strings_prg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupAnagram {

	
	public static void main(String[] args) {
		
		GroupAnagram main=new GroupAnagram();
		String[] inputarr= {"eat" ,"tea" , "tan" ,"ate", "nat" , "bat"};
		System.out.println(main.group(inputarr));
		
	}
	
	public List<List<String >> group(String [] inputarr){
		
		Map<String , List<String>> group=new HashMap<>(); // Empty  Map List
		//System.out.println(group);
		for(String str:inputarr) {
			char [] ch=str.toCharArray(); // String list to char so it take each word //EAT  //TEA
			System.out.println(ch);
			System.out.println("------");
			Arrays.sort(ch);  //sort the character //AET  //AET
			
			//valueOf :: you can convert int to string, long to string, boolean to string, character to string, float to string, double to string, object to string and char array to string.
			
			String sortedStr=String.valueOf(ch);  // stored in value place  // AET  //AET  
			System.out.println("uu"+sortedStr);   
			if(!group.containsKey(sortedStr)) {   //checking AET present in Empty MAP //AET not ther //AET is there
				group.put(sortedStr, new ArrayList<>());  //If not there add
				
			}
			group.get(sortedStr).add(str);  //If it is there add in value
		}
		return new ArrayList<>(group.values());
	}
}
