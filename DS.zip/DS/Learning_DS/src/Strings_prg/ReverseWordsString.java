package Strings_prg;

public class ReverseWordsString {
	
	public static void main(String[] args) {
		
		//https://www.youtube.com/watch?v=CSk6sB0c_CM
		String str="my name is tanveer";
		String str1="";
		String a[]=str.split(" ");
		
		
		for (int i = a.length-1; i >=0; i--) {
			
			str1=str1+a[i]+ " ";
			
		}
		System.out.println(str1);
	}

	
}
