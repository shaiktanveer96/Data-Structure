package Strings_prg;

public class LongestCommanPrefix {
	
	public static void main(String[] args) {
		
		String[] strs={"flower" , "flow","flight"};
		
		String s=longprefix(strs);
		System.out.println(s);
		
		
	}
	
	public static String longprefix(String [] strs)
	{
	
	if(strs.length == 0) 
		return "";
	
		String perfix= strs[0];
		System.out.println(perfix);//indexOf total index in word e.g: flower=6
		for (int i = 1; i < strs.length; i++) {
			while(strs[i].indexOf(perfix)!=0) {
				perfix=perfix.substring(0,perfix.length() - 1);
				if(perfix.isEmpty())
					return "";
				
			
		}
	}
	return perfix;
		
	}

}
