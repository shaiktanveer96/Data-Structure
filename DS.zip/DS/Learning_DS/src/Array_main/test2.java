package Array_main;

import java.text.SimpleDateFormat;
import java.util.Date;

public class test2 {
	
	public static void main(String[] args) {
		
		
		 Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	//	    String strDate= formatter.format(new 	date);  
		//    System.out.println(strDate);  
	}

}
