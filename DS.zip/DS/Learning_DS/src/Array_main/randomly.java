package Array_main;
import java.util.ArrayList;
import java.util.Random;

public class randomly {

	public static void main(String[] args) {
		
	
	


	//String intl_markets='ACA|AGU|AKL|AMS|ANU|ARN|ATH|AUA|BCN|BDA|BLM|BJX|BOG|BOM|BON|BRU|BZE|CDG|CTU|CUN|CUU|CZM|DEL|DLC|DUB|EDI|EIS|ELH|EZE|FCO|FPO|FRA|GCM|GDL|GGT|GHB|GIG|GLA|GRU|GUA|GVA|HAM|HAV|HKG|HND|HSU|HUX|ICN|IWK|KEF|KIX|KSA|KWA|LHR|LIM|LIR|LIS|MAD|MAJ|MAN|MBJ|MEL|MEX|MGA|MHH|MID|MKC|MLM|MNL|MSJ|MTY|MUC|MXP|MZT|NAS|NRT|OAX|OIT|OPO|PBC|PEK|PLS|PNI|POP|POS|PPT|PTK|PTY|PVG|PVR|QRO|ROR|RTB|SAL|SAP|SCL|SDJ|SDQ|SIN|SJD|SJO|SKB|SLP|SNN|STI|SXM|SYD|TAM|TCB|TGU|TKK|TLV|TPE|TXL|UIO|UVF|VCE|VER|VPS|VSA|YAP|YEG|YHZ|YOW|YQB|YUL|YVR|YWG|YYC|YYJ|YYZ|ZIH|ZLO|ZRH'


	


	ArrayList<String> list=new ArrayList<>();
	list.add("DEN");
	list.add("ORD");
	list.add("SFO");
	list.add("EWR");



	for(String str : list)
	{
		System.out.println(str);
	}

	Random rnd=new Random();
	String rndelement=list.get(rnd.nextInt(list.size()));


			System.out.println("test " +rndelement);


}
}