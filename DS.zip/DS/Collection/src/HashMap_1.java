import java.util.HashMap;
import java.util.Set;

public class HashMap_1 {
	
	public static void main(String[] args) {
		
		HashMap<String, String>	hmap=new HashMap<String, String>();
		
		hmap.put("England", "London");
		hmap.put("Germany", "Berlin");
		hmap.put("Norway", "Oslo");
		hmap.put("USA", "Washington DC");
	    System.out.println(hmap);
	    
	     System.out.println(hmap.get("England"));
	     
	     System.out.println(hmap.remove("USA"));
	     System.out.println(hmap.size());
	     
	     
	     
	   for(String i:hmap.keySet()) {
		   System.out.println(i);
	   }
		   
	     
		}
}
