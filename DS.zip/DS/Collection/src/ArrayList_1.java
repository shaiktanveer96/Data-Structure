import java.util.ArrayList;

public class ArrayList_1 {

	
	public static void main(String[] args) {
		
		ArrayList<String>  cars=new ArrayList<String>();
		
		cars.add("BMW");
		cars.add("audi");
		cars.add("toyate");
		cars.add("suzuki");
		cars.add("EY");
		
		System.out.println(cars);
		
		System.out.println(cars.get(3));
		
		cars.set(3, "nexa");
		
		System.out.println(cars.get(3));
		
		cars.remove(3);
		
		System.out.println(cars.size());
		
		for(int i=0;i<cars.size();i++) {
			System.out.println(cars.get(i));
		}
		
	}
}
