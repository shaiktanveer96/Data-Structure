package Nov_Week1;

public class A3_Palindrome {
	
	//palindrome or not --> true or false
	

public static void main(String[] args) {
		
	//	System.out.println(palindrom(123));
	}

	
}
  