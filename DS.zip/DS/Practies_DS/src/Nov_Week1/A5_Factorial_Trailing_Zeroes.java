package Nov_Week1;

public class A5_Factorial_Trailing_Zeroes {
	
	public static void main(String[] args) {
		
		
	//	System.out.println(trailingZero(2));
		//https://www.youtube.com/watch?v=pixOvDxipHI
		//Hint: loop with 5 and modulies with loop
		
	}
	
	
	
	}
