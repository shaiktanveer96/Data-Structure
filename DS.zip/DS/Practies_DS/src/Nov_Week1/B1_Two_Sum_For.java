package Nov_Week1;

import java.util.Arrays;

public class B1_Two_Sum_For {

	
	public static void main(String[] args) {
		
		

		int [] num= {2,7,11,15};
		int target=9;
		
		System.out.println(Arrays.toString(twosum(num,target)));
	}
	
	public static int[] twosum(int [] val, int tar) {
		
		for(int i=0;i< val.length;i++) {
			for(int j=i+1 ; j<val.length;j++) {
				if(val[i]+val[j]== tar) {
					return new int [] {i,j};
				}
			}
			
			
		}
		return new int [] {};
	}
	
	
}
