package Nov_Week1;

public class B6_LengthOfLastWord {

	//Just find length of last word 
	//1. Trim String and store in value
	//2.stored value loop it
	//3.IF stored value with chatAt should not equal with space -->count
	//4. else break

	public static void main(String[] args) {
		
		String s="Hello World in java";
		System.out.println(lengthOfLastWord(s));
		
	}
	public static int lengthOfLastWord(String str) {
		String tri=str.trim();
		int count = 0;
		for(int i=tri.length()-1;i>0;i--) {
			if(tri.charAt(i) != ' ') {
				count++;
			}else {
				break;
			}
		}
		return count;
	}

		
	}

