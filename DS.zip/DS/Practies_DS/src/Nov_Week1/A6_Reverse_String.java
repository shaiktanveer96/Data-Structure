package Nov_Week1;

public class A6_Reverse_String {
	
	public static void main(String[] args) {
		
		

		String str="my name is tanveer";
		}
}
