package Nov_Week1;

import java.util.Iterator;

public class A7_Reverse_Words {

	
	public static void main(String[] args) {
		String str="tanveer";
	  
		
	}
	
}
