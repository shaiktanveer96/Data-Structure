package Nov_Week1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;



public class A8_GroupAnagram {
	
	public static void main(String[] args) {
		
		A8_GroupAnagram main=new A8_GroupAnagram();
		String[] inputarr= {"eat" ,"tea" , "tan" ,"ate", "nat" , "bat"};
		System.out.println(main.group(inputarr));
		
	}

	public List<List<String>> group(String [] arry){
		
		HashMap <String , List<String>> hmap=new HashMap<>();
		
		for(int i=0;i<arry.length;i++) {
			    char [] ch=arry[i].toCharArray();
			    Arrays.sort(ch);
			    String sorted=String.valueOf(ch);
			    if(!hmap.containsKey(sorted)) {
			    	hmap.put(sorted, new ArrayList<>());
			    }
			    hmap.get(sorted).add(arry[i]);
		}
		return new ArrayList<>(hmap.values());
	}
	
}
