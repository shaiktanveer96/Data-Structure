package Nov_Week1;

public class B5_FindAllDuplicatesInArray_For {

	// return all duplicated numbers in output
	public static void main(String[] args) {
		
		int [] num= {2,7,11,15,2,11,7,3};
		
	
	}
}
