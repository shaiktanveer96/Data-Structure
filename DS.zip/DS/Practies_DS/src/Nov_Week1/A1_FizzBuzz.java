package Nov_Week1;

public class A1_FizzBuzz {
	
	public static void main(String[] args) {
		
		for (int i = 0; i <= 100; i++) {
		
			
		
			
			
		}
		
	}

}
