package Nov_Week1;

public class B3_ContainDuplicates_For {
	
	//1. loop with I,J 
	//2.check with i equal with j then true else false
	
	public static void main(String[] args) {
		
		int [] num= {2,7,11,15};
		//System.out.println((duplicate(num)));		
	}

	
	
}
