package Interger_DS;

public class A4_Factorial_Trailing_Zeroes {
	public static void main(String[] args) {
		
		
		System.out.println(trailingZero(25));
		//https://www.youtube.com/watch?v=pixOvDxipHI
	}

	
	public static int trailingZero(int n) {
		int count=0;
		
		for(int i=5;i<=n;i=i*5) {
			count=count+n/i;
			
		}
	return count;	
	}
	
}
