package Interger_DS;

public class A3_Palindrome {
	
public static void main(String[] args) {
		
		System.out.println(palindrom(121));
	}

 public static boolean palindrom(int x) {
	 
	 int rev= 0;
		int temp=x;
		
		while(x > 0) {
			int digit=x%10;
			 rev=(rev*10)+digit;
			 x=x/10;
		}if(rev == temp) {
			return true;
		}
		return false;
 }

}
