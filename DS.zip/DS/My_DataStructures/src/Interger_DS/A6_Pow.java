package Interger_DS;

public class A6_Pow {

}
