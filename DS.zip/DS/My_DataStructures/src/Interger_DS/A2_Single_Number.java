package Interger_DS;

public class A2_Single_Number {
	
	//Non-Repeated
	public static void main(String[] args) {
		int[] arr= {1,5,5,3,1,2,3};
		int results=singleValue(arr);
		System.out.println(results);
	}
	
	public static int singleValue(int [] num) {
		int result=0;
		
		for(int i=0;i<num.length;i++) {
			result=result ^ num[i];
		}
		return result;
	}

}
