package String;

public class A4_Reverse_Words {
	
	public static void main(String[] args) {
		String str="tanveer";
		String str1="";
		
	  for(int i=str.length()-1;i>=0;i--) {
		    char ch=str.charAt(i);
		    System.out.print(ch);
		    
	  }
		
	}

}
