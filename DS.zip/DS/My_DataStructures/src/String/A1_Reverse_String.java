package String;

public class A1_Reverse_String {
	
	public static void main(String[] args) {
		
		String str="my name is tanveer";
		String str1="";
		String a[]=str.split(" ");
		
		for(int i= a.length-1;i>=0;i--) {
			str1=str1+a[i]+" ";
		}
		System.out.println(str1);
	}

}
