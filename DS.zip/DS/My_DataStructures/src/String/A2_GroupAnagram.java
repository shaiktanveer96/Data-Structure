package String;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;



public class A2_GroupAnagram {
	
	
	public static void main(String[] args) {
		
		A2_GroupAnagram main=new A2_GroupAnagram();
		String[] inputarr= {"eat" ,"tea" , "tan" ,"ate", "nat" , "bat"};
		System.out.println(main.group(inputarr));
		
	}
	
	public List<List<String >> group(String [] inputarr){
	
		HashMap<String, List<String>> hmap=new HashMap<>();
		for(int i=0;i<inputarr.length;i++) {
			
			char [] ch=inputarr[i].toCharArray();
			 Arrays.sort(ch);
		     String sortedstring= String.valueOf(ch);
		     if(!hmap.containsKey(sortedstring)) {
		    	 hmap.put(sortedstring, new ArrayList<>());
		     }
		     
		       hmap.get(sortedstring).add(inputarr[i]);
		}
		
		return new ArrayList<>(hmap.values());
		
	}

}
