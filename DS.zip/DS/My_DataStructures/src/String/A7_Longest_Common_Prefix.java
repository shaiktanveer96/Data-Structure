package String;

public class A7_Longest_Common_Prefix {

}
