package BinarySearch;

public class A3_MissingNumber {
	
	public static void main(String[] args) {
		
		int[] num= {0,1};
		System.out.println((missingNumber(num)));
	}
	
	public static int missingNumber(int[]  nums) {
		int missing=nums.length;
		for (int i = 0; i < nums.length; i++) {
			missing ^=nums[i]^i;
			
		}
		return missing;
	}

}
