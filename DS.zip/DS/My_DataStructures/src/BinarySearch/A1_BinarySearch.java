package BinarySearch;

public class A1_BinarySearch {
	
	public static void main(String[] args) {
		
		   int[] L = {1,2,3,4,5,6,7,8};
	        
	        int target = 1;
	        int start = 0;
	        int end = L.length - 1;
	        
	        while (start <= end){
	            int mid = (start + end) / 2;
	            if (L[mid] == target){
	                System.out.println("Found.");
	                break;
	            } else if (L[mid] < target){
	                start = mid + 1;
	            } else if (L[mid] > target) {
	                end = mid - 1;
	            }
	        }
	        
	        if (start > end){
	            System.out.println("Item not found");
	        } else {
	            System.out.println("Item  found.");
	        }
	}

}
