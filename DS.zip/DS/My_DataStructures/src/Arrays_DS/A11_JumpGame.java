package Arrays_DS;

public class A11_JumpGame {
	
	public static void main(String[] args) {
		
	
	int [] ary= {3,2,1,0,4};
	System.out.println((canJump(ary)));	
	
	
	}

	public static boolean  canJump(int [] num) {
		int lastIndexPosition=num.length-1;
		for (int i = num.length-1;i >=0;i--) {
			if(i + num[i] >= lastIndexPosition) {
				lastIndexPosition =i;
			}
		}
		return lastIndexPosition == 0;
	}
}
