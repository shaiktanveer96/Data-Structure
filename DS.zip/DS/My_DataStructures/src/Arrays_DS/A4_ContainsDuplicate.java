package Arrays_DS;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class A4_ContainsDuplicate {
	
	public static void main(String[] args) {
		
		int [] num= {2,7,11,15,2};
		
		
		System.out.println((duplicate(num)));
	}
	
	public static boolean duplicate(int [] num) {
		Set<Integer> set=new HashSet<>();
		for(int i=0; i< num.length;i++) {
			if(set.contains(num[i])) {
				return true;
			}else {
				set.add(num[i]);
			}
		}
		
		return false;
	}

}
