package Arrays_DS;

public class A3_BuyTimeToBuyAndSellStock {
	
	public static void main(String[] args) {
		
		
		int[] prices= {7,1,5,3,6,4};
		System.out.println(maxProfit(prices));
		
	}

	
	public static int maxProfit(int[] price) {
		
		if(price.length ==1 ) return 0;
		
		int proft=0;
		int left=0;
		for(int right=0;right<price.length;right++) {
			if(price[right] > price[left]) {
				proft=Math.max(proft, price[right] - price[left]);
			}else {
				left=right;
			}
		}
		return proft;
	}
}
