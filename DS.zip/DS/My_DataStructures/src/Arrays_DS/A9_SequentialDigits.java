package Arrays_DS;

import java.util.ArrayList;
import java.util.List;

public class A9_SequentialDigits {
	
	public static void main(String[] args) {
		
		int low=100;
		int high=300;
		System.out.println(seqDigits(low, high));
		
	}
	
	public static List<Integer> seqDigits(int low, int high){
		
		List<Integer> ls=new ArrayList<>();
		for(int i=1; i< 10; i++ ) {
			int next=0;
			for (int j = i; j < 10; j++) {
				next=next*10+j;
				if(next >=low && next <=high) {
					ls.add(next);
					
				}else if(low>high) {
					break;
				}
					
			}
		}
	  return ls;	
	}
	

}
