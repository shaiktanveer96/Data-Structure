package Arrays_DS;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class AA1_FindAllDuplicatesInArray_For {
	
	public static void main(String[] args) {
		
		int [] num= {2,7,11,15,2,11,7};
		
		for (int i = 0; i < num.length-1; i++) {
			for (int j = i+1; j < num.length; j++) {
				if(num[i] == num[j]) {
					System.out.println(num[i]);
				}
			}
		}
	
	}

}
