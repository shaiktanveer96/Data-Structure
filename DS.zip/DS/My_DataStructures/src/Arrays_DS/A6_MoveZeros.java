package Arrays_DS;

import java.util.Arrays;

public class A6_MoveZeros {
	
	public static void main(String[] args) {
		
		
		int[] arr= {0,1,0,12};
	//	int [] t=A6_MoveZeros.movezero(arr);
		
	}

	
	public static void movezero(int[] num) {
		if(num.length == 1) return;
		int left=0;
		for(int right=0;right<num.length;right++) {
			if(num[right]  !=0) {
				num[left]=num[right];
				left++;
			}
			
		}
		for(int i=left;i<num.length;i++) {
			num[left]=0;
		}
		
		
		
	}
}
