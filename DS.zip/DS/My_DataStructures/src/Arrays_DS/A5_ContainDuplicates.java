package Arrays_DS;

public class A5_ContainDuplicates {
	
	public static void main(String[] args) {
		
		int [] num= {2,7,11,15};
		System.out.println((duplicate(num)));		
	}	
		public static boolean duplicate(int[] num) {
		for(int i=0 ;i < num.length;i++) {
			for(int j=i+1;j<num.length;j++) {
				if(num[i]== num[j]) {
					return true;
				}
				}
			}
		
	return false;

}
}