package Arrays_DS;

public class A8_LengthOfLastWord {

	
	public static void main(String[] args) {
		
		String s="Hello World in java";
		System.out.println(lengthOfLastWord(s));
		
	}
	
	public static int lengthOfLastWord(String s) {
		String str=s.trim();
		int count=0;
		for(int i=str.length()-1;i>=0;i--) {
			if(str.charAt(i) != ' ') {
				count++;
			}else {
				break;
			}
		}
		return count;
		
		
	}
}
